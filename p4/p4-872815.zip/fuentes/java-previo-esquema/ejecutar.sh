java -cp "bin:lib/*" uni.Test3
#el contenedor debe estar corriendo con docker-compose up -d